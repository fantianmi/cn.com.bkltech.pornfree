<?php

namespace Addons\demo\Controller;
use Home\Controller\AddonsController;

class demoController extends AddonsController{

}

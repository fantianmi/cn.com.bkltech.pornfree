<?php
namespace Common\Model;
use Think\Model;

class JingchongModel extends Model
{
/**
*获取用户的精虫上脑列表
*@return  array
*/
	public function getUserList($uid,$order='ctime DESC')
	{
		$map['uid'] = $uid;
		$list = $this->where($map)->order($order)->select();
		return $list;
	}
}





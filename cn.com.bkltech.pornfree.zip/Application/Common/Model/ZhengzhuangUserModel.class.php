<?php
namespace Common\Model;
use Think\Model;

class ZhengzhuangUserModel extends Model
{
/**
*获取用户的症状
*@param   $uid    用户id
*@return  array
*/
	public function getUserZheng($uid)
	{
		// header("content-type:text/html;charset=utf-8");
		$map['thinkox_zhengzhuang_user.uid'] = $uid;
		$field = array(
			'thinkox_zhengzhuang_user.zid',
			'thinkox_zhengzhuang.name',
			'thinkox_zhengzhuang_user.create_time'
		);
		$order = 'thinkox_zhengzhuang_user.create_time DESC';
		$zhengList = $this->field($field)->where($map)->join('__ZHENGZHUANG__ ON __ZHENGZHUANG__.id=thinkox_zhengzhuang_user.zid','LEFT')->order($order)->select();
		return $zhengList;
	}

}






<?php
namespace Detail\Controller;
use Think\Controller;

class IndexController extends Controller
{
/**
*APP端查看文章的详情
*@param   $id   文章的id
*/
	function index()
	{
		$id = I('id','','intval');
		if(empty($id)) exit( err(100) );
		$data = D('Document')->detail($id);
		$this->assign('data',$data);
		$this->display();
	}
/**
*关于我们页面
*/
	public function about(){
		$data = M('abouts')->find('1');
		$this->assign('content',$data['content']);
		$this->display();
	}

}





<?php
return array(
	/* 模板相关配置 */
    'TMPL_PARSE_STRING' => array(
        '__CSS__'    => __ROOT__ . '/Public/' . MODULE_NAME . '/css',
    ),



);





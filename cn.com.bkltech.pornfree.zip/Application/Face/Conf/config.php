<?php
return array(
	   'DEFAULT_THEME' =>  'default',  // 默认模板主题名称
);


